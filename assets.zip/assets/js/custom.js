$(document).ready(function(){
		  $(".header-nav-prod").hover(function(){
			var currentPath= window.location.pathname.split("/")[7].split(".")[0];
			$(".header").addClass("backgrd-white");
			$("section").addClass("fadeIn");
			$("."+currentPath).addClass('cur-product');
			}, function(){
			$(".header").removeClass("backgrd-white");
			$("section").removeClass("fadeIn");
		  });
		});