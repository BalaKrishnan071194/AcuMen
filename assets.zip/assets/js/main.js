!(function (e) {
    "use strict";
    if (
        (e('ul.nav li a[href="#"]').on("click", function (e) {
            e.preventDefault();
        }),
        e(".header ul.nav > li > a").append('<span class="menu-mark"></span>'),
        e(".nav-wrapper").menumaker({ title: "<span></span>", format: "multitoggle" }),
        e(e(window)).on("scroll", function () {
            e("ul.nav").hasClass("open") || e("#menu-button").removeClass("menu-opened");
        }),
        e(window).width() >= 992)
    ) {
        e(".menu-trigger").on("click", function () {
            e(this).toggleClass("active"), e(".main-menu-wrapper").toggleClass("show"), e(".logo-holder").toggleClass("d-none"), e(".nav-wrapper").toggleClass("active");
        });
    }
    e(window).on("scroll", function () {
        e(window).scrollTop() < 0 ? e(".header-main.love-sticky").removeClass("sticky fadeInDown animated") : e(".header-main.love-sticky").addClass("sticky fadeInDown animated");
    }),
        e("[data-bg-img]")
            .css("background-image", function () {
                return 'url("' + e(this).data("bg-img") + '")';
            })
            .removeAttr("data-bg-img")
            .addClass("bg-img");
    var a = function (e, a) {
        return void 0 === e ? a : e;
    };
  

   
})(jQuery);
